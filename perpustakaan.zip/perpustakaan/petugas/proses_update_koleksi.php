<?php 
// koneksi database
include '../koneksi.php';
   
// menangkap data yang di kirim dari form
$KategoriBukuID = $_POST['KategoriBukuID'];
$BukuID = $_POST['BukuID'];
$KategoriID = $_POST['KategoriID'];
 
// menginput data ke database
mysqli_query($koneksi,"UPDATE `kategoribuku_relasi` SET `BukuID` = '$BukuID', `KategoriID` = '$KategoriID' WHERE `kategoribuku_relasi`.`KategoriBukuID` = '$KategoriBukuID'");
 
// mengalihkan halaman kembali ke kategori.php
header("location:koleksi.php?pesan=update");
 
?>