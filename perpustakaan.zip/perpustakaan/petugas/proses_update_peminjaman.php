<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// koneksi database
include '../koneksi.php';
   
// menangkap data yang di kirim dari form
$PeminjamanID = $_POST['PeminjamanID'];
$UserID = $_POST['UserID'];
$BukuID = $_POST['BukuID'];
$TanggalPeminjaman = $_POST['TanggalPeminjaman'];
$TanggalPengembalian = $_POST['TanggalPengembalian'];
$StatusPeminjaman = $_POST['StatusPeminjaman'];

// menginput data ke database
//mysqli_query($koneksi,"update peminjaman set UserID='$UserID', BukuID='$BukuID', TanggalPeminjaman='$TanggalPeminjaman', TanggalPengembalian='$TanggalPengembalian', StatusPeminjaman='$StatusPeminjaman' where PeminjamanID='$PeminjamanID'");
// mysqli_query($koneksi,"UPDATE `peminjaman` SET `id_user` = '$id_user', `id_buku` = '$id_buku', `tanggal_peminjaman` = '$tanggal_peminjaman', `tanggal_pengembalian` = '$tanggal_pengembalian', `StatusPeminjaman` = '$StatusPeminjaman' WHERE `peminjaman`.`PeminjamanID` = $PeminjamanID"); 
if (!$koneksi -> query("UPDATE `peminjaman` SET `UserID` = '$UserID', `BukuID` = '$BukuID', `TanggalPeminjaman` = '$TanggalPeminjaman', `TanggalPengembalian` = '$TanggalPengembalian', `StatusPeminjaman` = '$StatusPeminjaman' WHERE `peminjaman`.`PeminjamanID` = $PeminjamanID")) {
    echo("Error description: " . $koneksi -> error);
  }
// mengalihkan halaman kembali ke kategori.php
header("location:peminjaman.php?pesan=update");
 
?>