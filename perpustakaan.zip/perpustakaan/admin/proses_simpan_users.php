<?php 
// koneksi database
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$UserID = $_POST['UserID'];
$Username = $_POST['Username'];
$Password = md5($_POST['Password']);
$Email = $_POST['Email'];
$NamaLengkap = $_POST['NamaLengkap'];
$Alamat = $_POST['Alamat'];
$Level = $_POST['Level'];

//INSERT INTO `user`(`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`, `Level`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]')
// menginput data ke database
//mysqli_query($koneksi,"INSERT INTO `user`(`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`, `Level`) VALUES (NULL,'$Username','$Password','$Email','$NamaLengkap','$Alamat','$Level')");
mysqli_query($koneksi,"INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`, `Level`) VALUES (NULL ,'$Username' ,'$Password' ,'$Email' ,'$NamaLengkap' ,'$Alamat' ,'$Level')");

// mengalihkan halaman kembali ke index.php
header("location:users.php?pesan=update");
 
?>